// const axios = require('axios');
// const xlsx = require('xlsx');
import axios from 'axios'
import xlsx from 'xlsx'
// Define the API endpoint
const API_URL = 'http://localhost:5000/provider';

// Function to read data from an Excel file
const readExcelData = (filePath) => {
    const workbook = xlsx.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    return xlsx.utils.sheet_to_json(sheet);
};

// Function to upload data
const uploadData = async (filePath) => {
    try {
        const providers = readExcelData(filePath);
        console.log('providers',providers)
        for (const provider of providers) {
            const response = await axios.post(API_URL, provider);
            console.log(`Uploaded: ${provider.name} - Status: ${response.status}`);
        }
        console.log('All data uploaded successfully!');
    } catch (error) {
        console.error('Error uploading data:', error.message);
    }
};

// Execute the function with the Excel file path
uploadData('PROVEEDORES FINAL VERSION.xlsx');



// import axios from 'axios'
// import xlsx from 'xlsx'

// // Define the API endpoint
// const API_URL = 'http://localhost:5000/bank';

// // Data array
// const categories = [
//     "Atlas Bank",
//     "Bac International Bank, Inc.",
//     "Banco Aliado, S.A.",
//     "Banco Azteca (Panamá), S.A.",
//     "Banco Davivienda (Panamá), S.A.",
//     "Banco Delta, S.A. (BMF)",
//     "Pacific Bank, S.A.",
//     "Banco Ficohsa (Panamá), S.A.",
//     "Banco General, S.A.",
//     "Banco Internacional de Costa Rica, S.A. (Bicsa)",
//     "Banco Lafise Panamá, S.A.",
//     "Banco La Hipotecaria, S.A.",
//     "Banco Latinoamericano de Comercio Exterior, S.A. (Bladex)",
//     "Bancolombia (Sucursal Panamá)",
//     "Banco Nacional de Panamá.",
//     "Banco Pichincha Panamá S.A.",
//     "The Bank of Nova Scotia, Sucursal Panamá",
//     "Banesco (Panamá), S.A.",
//     "Banisi, S.A.",
//     "Banistmo, S.A.",
//     "Bank of China (Sucursal Panamá), S.A.",
//     "BBP Bank, S.A.",
//     "BCT Bank International, S.A.",
//     "Bi Bank, S.A.",
//     "Caja de Ahorros",
//     "Canal Bank, S.A.",
//     "Capital Bank, Inc.",
//     "Citibank, N.A. (Sucursal Panamá)",
//     "Credicorp Bank, S.A.",
//     "Keb Hana Bank",
//     "Global Bank Corporation",
//     "Mercantil Banco, S.A.",
//     "Mega International Commercial Bank Co., Ltd. (Mega Icbc)",
//     "Multibank, Inc.",
//     "Metrobank, S.A.",
//     "MMG Bank Corporation",
//     "Prival Bank, S.A.",
//     "St. Georges Bank",
//     "Towerbank International, Inc.",
//     "Unibank, S.A.",
//     "ASB BANK CORP.",
//     "Austrobank Overseas (Panamá), S.A.",
//     "Banco Credit Andorra (Panamá), S.A.",
//     "Banco de Bogotá (Panamá), S.A.",
//     "Banco de Crédito del Perú (Sucursal Panamá)",
//     "Banco de Occidente (Panamá), S.A.",
//     "Bancolombia (Panamá), S.A.",
//     "BHD International Bank (Panamá), S.A.",
//     "BPR Bank, S.A.",
//     "GNB Sudameris Bank, S.A.",
//     "Inteligo Bank, Ltd.",
//     "Itaú (Panamá), S.A.",
//     "Popular Bank Ltd., Inc."
//   ];

// // Convert array to object format
// const providers = categories.map(category => ({ name: category }));

// // Function to upload data
// const uploadData = async () => {
//     try {
//         for (const provider of providers) {
//             const response = await axios.post(API_URL, provider);
//             console.log(`Uploaded: ${provider.name} - Status: ${response.status}`);
//         }
//         console.log('All data uploaded successfully!');
//     } catch (error) {
//         console.error('Error uploading data:', error.message);
//     }
// };

// // Execute the function
// uploadData();

import mongoose from 'mongoose';


const bankSchema = new mongoose.Schema({
    addedBy: { type: mongoose.Types.ObjectId },
    name: { type: String },
    isDelete:{ type: Boolean, default: false },
    isActive:{ type: Boolean, default: true }, 
});

const Bank = mongoose.model('Bank', bankSchema);
export default Bank;
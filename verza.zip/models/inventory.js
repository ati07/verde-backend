import mongoose from 'mongoose';

const inventorySchema = mongoose.Schema({
    addedBy: { type: mongoose.Types.ObjectId },
    clientId:{ type: mongoose.Types.ObjectId },
    projectId: { type: mongoose.Types.ObjectId },
    statusId:{ type: mongoose.Types.ObjectId },
    userId:{ type: mongoose.Types.ObjectId },
    code: { type: String },
    unitName:{ type: String, required: true },
    met2: { type: String },
    unitArea: { type: Number },
    priceArea: { type: Number },
    priceList: { type: Number },
    rooms: { type: Number },
    parking: { type: String },
    bathroom: { type: String },
    deposit:{ type: String },
    view: { type: Number, default: 0 },
    signatureDate: { type: Date },
    comment:{ type: String },
    isDelete:{ type: Boolean, default: false },
    isActive:{ type: Boolean, default: true }, 
},
{ timestamps: true }
)
const Inventory = mongoose.model('Inventory', inventorySchema);
export default Inventory;
import mongoose from 'mongoose';


const subPhaseSchema = new mongoose.Schema({
    addedBy: { type: mongoose.Types.ObjectId },
    name: { type: String },
    isDelete:{ type: Boolean, default: false },
    isActive:{ type: Boolean, default: true }, 
});

const SubPhase = mongoose.model('SubPhaseSchema', subPhaseSchema);
export default SubPhase;